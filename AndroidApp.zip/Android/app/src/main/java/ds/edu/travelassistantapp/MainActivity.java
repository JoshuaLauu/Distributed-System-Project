// Name: Junxuan(Joshua) Liu
// Andrew ID: junxuanl

package ds.edu.travelassistantapp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.util.Log;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private EditText originEditText, budgetEditText;
    private TextView resultTextView;
    private ImageView travelIconImageView;
    private Button fetchDataButton;

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                // For modern Android versions (API 23+)
                Network network = connectivityManager.getActiveNetwork();
                if (network == null) return false;

                NetworkCapabilities capabilities =
                        connectivityManager.getNetworkCapabilities(network);
                return capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            } else {
                // For older Android versions
                NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
                return activeNetworkInfo != null && activeNetworkInfo.isConnected();
            }
        }
        return false;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        originEditText = findViewById(R.id.originEditText);
        budgetEditText = findViewById(R.id.budgetEditText);
        resultTextView = findViewById(R.id.resultTextView);
        fetchDataButton = findViewById(R.id.fetchDataButton);
        travelIconImageView = findViewById(R.id.travelIconImageView);

        // Fetch Data Button Click Listener
        fetchDataButton.setOnClickListener(v -> {
            String origin = originEditText.getText().toString().trim();
            String budget = budgetEditText.getText().toString().trim();

            // Validate Origin City
            if (origin.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a valid origin city", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate Budget
            if (budget.isEmpty() || !budget.matches("\\d+")) {
                Toast.makeText(MainActivity.this, "Please enter a valid numeric budget", Toast.LENGTH_SHORT).show();
                return;
            }

            // Network Check
            if (!isNetworkAvailable()) {
                Toast.makeText(MainActivity.this, "No internet connection. Please try again later.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Proceed if inputs are valid
            fetchDataFromWebService(origin, budget);
        });

    }

    private void fetchDataFromWebService(String origin, String budget) {
        String url = "https://laughing-space-meme-5gxg7r4v4959fp6vj-8080.app.github.dev/travel?origin=" + origin + "&maxPrice=" + budget;
        Log.e("test", "url: "+url);

        // Show feedback to the user
        Toast.makeText(MainActivity.this, "Fetching destinations...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                // Open connection
                URL apiUrl = new URL(url);
                connection = (HttpURLConnection) apiUrl.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000); // 10 seconds timeout
                connection.setReadTimeout(10000);

                // Check response code
                int responseCode = connection.getResponseCode();
                Log.e("test","response cpde: " + responseCode);
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read response
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder responseBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        responseBuilder.append(line);
                    }
                    reader.close();

                    // Parse JSON Response
                    String jsonResponse = responseBuilder.toString();
                    Log.e("test", "response body: " + jsonResponse);

                    JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

                    // Check if "data" exists and is not empty
                    if (!jsonObject.has("data") || jsonObject.getAsJsonArray("data").size() == 0) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "No destinations found for the given criteria.", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    JsonArray destinations = jsonObject.getAsJsonArray("data");
                    StringBuilder results = new StringBuilder();
                    for (int i = 0; i < destinations.size(); i++) {
                        JsonObject destination = destinations.get(i).getAsJsonObject();
                        String city = destination.get("destination").getAsString(); // 修改为 "destination"
                        String departureDate = destination.get("departureDate").getAsString();
                        String price = destination.get("price").getAsJsonObject().get("total").getAsString();

                        results.append("City: ").append(city)
                                .append(", Departure: ").append(departureDate)
                                .append(", Price: ").append(price).append("\n");
                    }

// Update UI (on Main Thread)
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Destinations fetched successfully!", Toast.LENGTH_SHORT).show();
                        resultTextView.setText(results.toString());
                    });


                } else {
                    // Handle HTTP response errors
                    String errorMessage = "HTTP error: " + responseCode + " - " + connection.getResponseMessage();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show());
                }

            } catch (IOException e) {
                // Handle network errors
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Network error: Unable to fetch data.", Toast.LENGTH_SHORT).show());
                Log.e("test", e.getMessage());
                e.printStackTrace();
            } catch (Exception e) {
                // Handle unexpected errors
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Unexpected error occurred. Please try again.", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }


}