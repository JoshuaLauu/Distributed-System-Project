// Name: Junxuan(Joshua) Liu
// Andrew ID: junxuanl

package com.example.demo1;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MongoLogModel {
    private static final String MONGO_URI = "mongodb+srv://junxuanl:Lljjxx0325@cluster0.x4c6i.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    private static final String DATABASE_NAME = "travelApp";
    private static final String COLLECTION_NAME = "logs";

    private static MongoClient mongoClient; // Persistent MongoClient instance
    private static MongoCollection<Document> logCollection;

    // Initialize MongoClient and logCollection only once
    static {
        mongoClient = MongoClients.create(MONGO_URI);
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        logCollection = database.getCollection(COLLECTION_NAME);
    }

    // Log successful API requests
    public void logSuccess(Date timestamp, String origin, String maxPrice, long responseTime, int responseSize) {
        logToDatabase(new Document()
                .append("timestamp", timestamp)
                .append("parameters", new Document("origin", origin).append("maxPrice", maxPrice))
                .append("apiResponseTime", responseTime)
                .append("apiStatus", "success")
                .append("responseSize", responseSize));
    }

    // Log errors or failures
    public void logError(Date timestamp, String origin, String maxPrice, String errorMessage) {
        logToDatabase(new Document()
                .append("timestamp", timestamp)
                .append("parameters", new Document("origin", origin).append("maxPrice", maxPrice))
                .append("apiResponseTime", 0) // No response time for failures
                .append("apiStatus", "failure")
                .append("errorMessage", errorMessage));
    }

    // Save the log entry into MongoDB
    private void logToDatabase(Document logEntry) {
        try {
            logCollection.insertOne(logEntry);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Retrieve all logs from MongoDB
    public List<Document> getAllLogs() {
        try {
            return logCollection.find().into(new ArrayList<>());
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Get top N most requested origin cities
    public List<Document> getTopOriginCities(int limit) {
        try {
            return logCollection.aggregate(List.of(
                    new Document("$group", new Document("_id", "$parameters.origin").append("count", new Document("$sum", 1))),
                    new Document("$sort", new Document("count", -1)),
                    new Document("$limit", limit)
            )).into(new ArrayList<>());
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Get average API response time
    public Double getAverageResponseTime() {
        try {
            Document result = logCollection.aggregate(List.of(
                    new Document("$group", new Document("_id", null).append("avgTime", new Document("$avg", "$apiResponseTime")))
            )).first();
            return result != null ? result.getDouble("avgTime") : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Get top N most frequent max price requests
    public List<Document> getTopMaxPriceRequests(int limit) {
        try {
            return logCollection.aggregate(List.of(
                    new Document("$group", new Document("_id", "$parameters.maxPrice").append("count", new Document("$sum", 1))),
                    new Document("$sort", new Document("count", -1)),
                    new Document("$limit", limit)
            )).into(new ArrayList<>());
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Close MongoClient when the application is shutting down
    public static void closeMongoClient() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
