// Name: Junxuan(Joshua) Liu
// Andrew ID: junxuanl

package com.example.demo1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/logs")
public class LoggingServlet extends HttpServlet {
    private final MongoLogModel mongoLogModel = new MongoLogModel(); // Single instance of MongoLogModel

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action"); // Determine action: logs or analytics

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Travel Service Dashboard</h1>");

        if ("logs".equalsIgnoreCase(action)) {
            out.println("<h2>Request Logs</h2>");
            displayLogs(out); // Display all logs
        } else if ("analytics".equalsIgnoreCase(action)) {
            out.println("<h2>Operations Analytics</h2>");
            displayAnalytics(out); // Display analytics
        } else {
            out.println("<h2>Error</h2>");
            out.println("<p>Invalid action. Use 'logs' or 'analytics'.</p>");
        }

        out.println("</body></html>");
        out.flush();
    }

    // Display all logs in a human-readable table format
    private void displayLogs(PrintWriter out) {
        out.println("<table border='1'>");
        out.println("<tr><th>Timestamp</th><th>Origin</th><th>Max Price</th><th>API Response Time (ms)</th><th>Status</th><th>Response Size (bytes)</th></tr>");

        // Retrieve logs using the reused MongoLogModel instance
        List<Document> logs = mongoLogModel.getAllLogs();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        for (Document log : logs) {
            Document parameters = log.get("parameters", Document.class);
            String origin = parameters != null ? parameters.getString("origin") : "N/A";
            String maxPrice = parameters != null ? parameters.getString("maxPrice") : "N/A";

            // Format the timestamp
            Date timestamp = log.getDate("timestamp");
            String formattedTimestamp = timestamp != null ? dateFormat.format(timestamp) : "N/A";

            out.println("<tr>");
            out.println("<td>" + formattedTimestamp + "</td>");
            out.println("<td>" + origin + "</td>");
            out.println("<td>" + maxPrice + "</td>");
            out.println("<td>" + log.getOrDefault("apiResponseTime", "N/A") + "</td>");
            out.println("<td>" + log.getString("apiStatus") + "</td>");
            out.println("<td>" + log.getOrDefault("responseSize", "N/A") + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
    }

    // Display analytics in a human-readable format
    private void displayAnalytics(PrintWriter out) {
        out.println("<h3>Top 5 Origin Cities</h3>");
        List<Document> topOrigins = mongoLogModel.getTopOriginCities(5); // Fetch top 5 origin cities
        out.println("<ul>");
        for (Document origin : topOrigins) {
            out.println("<li>" + origin.getString("_id") + ": " + origin.getInteger("count") + " requests</li>");
        }
        out.println("</ul>");

        out.println("<h3>Average API Response Time</h3>");
        Double avgResponseTime = mongoLogModel.getAverageResponseTime(); // Fetch average API response time
        out.println("<p>Average API Response Time: " + (avgResponseTime != null ? avgResponseTime : "N/A") + " ms</p>");

        out.println("<h3>Most Frequent Max Price Requests</h3>");
        List<Document> topPriceRanges = mongoLogModel.getTopMaxPriceRequests(3); // Fetch top 3 max price requests
        out.println("<ul>");
        for (Document price : topPriceRanges) {
            out.println("<li>Max Price: " + price.getString("_id") + ", " + price.getInteger("count") + " requests</li>");
        }
        out.println("</ul>");
    }
}
