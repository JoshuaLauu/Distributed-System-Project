// Name: Junxuan(Joshua) Liu
// Andrew ID: junxuanl

package com.example.demo1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Logger;

@WebServlet("/travel") // Simplified mapping
public class TravelServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(TravelServlet.class.getName());
    private final AmadeusApiModel amadeusApiModel = new AmadeusApiModel();
    private final MongoLogModel mongoLogModel = new MongoLogModel();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("Received request at /travel");

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String origin = request.getParameter("origin");
        String maxPrice = request.getParameter("maxPrice");

        logger.info("Parameters - origin: " + origin + ", maxPrice: " + maxPrice);

        // Log missing parameters
        if (origin == null || maxPrice == null) {
            mongoLogModel.logError(new Date(), origin, maxPrice, "Missing required parameters");
            sendError(response, "Missing required parameters: origin or maxPrice");
            return;
        }

        try {
            // Fetch data from Amadeus API
            long startTime = System.currentTimeMillis();
            String amadeusData = amadeusApiModel.fetchFlightDestinations(origin, maxPrice);
            long responseTime = System.currentTimeMillis() - startTime;

            // Send response to the client
            JSONObject amadeusJson = new JSONObject(amadeusData);
            response.getWriter().write(amadeusJson.toString());

            // Log success
            mongoLogModel.logSuccess(new Date(), origin, maxPrice, responseTime, amadeusData.length());
        } catch (Exception e) {
            logger.severe("Error occurred: " + e.getMessage());
            e.printStackTrace();

            // Log failure
            mongoLogModel.logError(new Date(), origin, maxPrice, e.getMessage());
            sendError(response, "Failed to fetch travel data: " + e.getMessage());
        }
    }

    private void sendError(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        JSONObject errorResponse = new JSONObject();
        errorResponse.put("error", message);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(errorResponse.toString());
    }
}
