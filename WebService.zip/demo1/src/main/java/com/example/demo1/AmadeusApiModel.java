// Name: Junxuan(Joshua) Liu
// Andrew ID: junxuanl


package com.example.demo1;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class AmadeusApiModel {
    private static final String API_KEY = "U2XzpXI294r5mb5TR0wAQLQn7JbXcvp7";
    private static final String API_SECRET = "TKMYEtA9qhDCBU4U";
    private static final String TOKEN_URL = "https://test.api.amadeus.com/v1/security/oauth2/token";
    private String accessToken;

    // Fetch flight destinations from the Amadeus API
    public String fetchFlightDestinations(String origin, String maxPrice) throws Exception {
        if (accessToken == null || accessToken.isEmpty()) {
            accessToken = getAccessToken();
        }

        String amadeusUrl = String.format(
                "https://test.api.amadeus.com/v1/shopping/flight-destinations?origin=%s&maxPrice=%s",
                URLEncoder.encode(origin, StandardCharsets.UTF_8),
                URLEncoder.encode(maxPrice, StandardCharsets.UTF_8)
        );

        HttpURLConnection conn = (HttpURLConnection) new URL(amadeusUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);

        if (conn.getResponseCode() == 401) {
            // Token expired, refresh it
            accessToken = getAccessToken();
            return fetchFlightDestinations(origin, maxPrice);
        }

        return readResponse(conn);
    }

    // Obtain a new access token
    private String getAccessToken() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(TOKEN_URL).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        String postData = String.format("grant_type=client_credentials&client_id=%s&client_secret=%s",
                API_KEY, API_SECRET);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(postData.getBytes(StandardCharsets.UTF_8));
        }

        return new JSONObject(readResponse(conn)).getString("access_token");
    }

    // Read the response from an HTTP connection
    private String readResponse(HttpURLConnection conn) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            return response.toString();
        }
    }
}
